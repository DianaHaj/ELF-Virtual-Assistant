import json, os, re, string
from datetime import datetime, timedelta
import streamlit as st
from streamlit_notifications import send_alert

reminder_file = 'reminders.json'
reminders = []

def save_reminders_to_file():
    with open(reminder_file, 'w') as file:
        json_reminders = [{'message': reminder['message'], 'time': reminder['time'].isoformat()} for reminder in reminders]
        json.dump(json_reminders, file)

def load_reminders_from_file():
    if os.path.exists(reminder_file):
        with open(reminder_file, 'r') as file:
            json_reminders = json.load(file)
            for json_reminder in json_reminders:
                reminders.append({
                    'message': json_reminder['message'],
                    'time': datetime.fromisoformat(json_reminder['time'])
                })

def add_reminder(reminder_dict):
    reminders.append(reminder_dict)
    save_reminders_to_file()

def parse_date_time(user_input):
    current_time = datetime.now()
    
    match = re.search(r'(in|after|next) (\d+|an|a|week|day|hour) (minutes?|hours?|days?|weeks?)?(?:\s*at\s*(\d{1,2})(?::(\d{2}))?\s*(AM|PM)?)?', user_input, re.IGNORECASE)
    if match:
        
        full_text = match.group(0).lower()
        
        direction = 'in' 
        amount = 0
        unit = ''

        #parsing rules
        if 'next' in full_text:
            direction = 'next'
        elif 'in' in full_text or 'after' in full_text:
            direction = 'in' if 'in' in full_text else 'after'

        #extract amount and unit
        amount_match = re.search(r'(\d+|an|a)', full_text)
        if amount_match:
            amount_str = amount_match.group(0)
            amount = 1 if amount_str in ['an', 'next', 'a'] else int(amount_str)

        unit_match = re.search(r'(minutes?|hours?|days?|weeks?)', full_text)
        if unit_match:
            unit = unit_match.group(0)
        
        #adjustment of base reminder time
        if direction == 'in' or direction == 'after':
            if 'minute' in unit:
                reminder_time = current_time + timedelta(minutes=amount)
            elif 'hour' in unit:
                reminder_time = current_time + timedelta(hours=amount)
            elif 'day' in unit:
                reminder_time = current_time + timedelta(days=amount)
            elif 'week' in unit:
                reminder_time = current_time + timedelta(weeks=amount)
            else:
                reminder_time = current_time
        elif direction == 'next':
            if 'week' in unit:
                reminder_time = current_time + timedelta(weeks=1)
            elif 'day' in unit:
                reminder_time = current_time + timedelta(days=7)
            else:
                reminder_time = current_time
        
        #parsing of specific time if present
        time_match = re.search(r'at\s*(\d{1,2})(?::(\d{2}))?\s*(AM|PM)?', full_text)
        if time_match:
            hour_str = time_match.group(1)
            minute_str = time_match.group(2) if time_match.group(2) else '00'
            am_pm = time_match.group(3)
            
            if hour_str:
                hour = int(hour_str)
                minute = int(minute_str)
                if am_pm and am_pm.lower() == 'pm' and hour != 12:
                    hour += 12
                elif am_pm and am_pm.lower() == 'am' and hour == 12:
                    hour = 0
                
                reminder_time = reminder_time.replace(hour=hour, minute=minute, second=0, microsecond=0)
        
        return reminder_time
    
    return None

def handle_user_input(user_input):
    reminder_message_raw = extract_reminder_message(user_input)
    reminder_message = ''.join(filter(lambda x: x.isalpha() or x.isdigit() or x.isspace(), reminder_message_raw))
    reminder_time = parse_date_time(user_input)
  
    if reminder_message and reminder_time:
        reminder_time_str = reminder_time.strftime('%I:%M %p on %B %d, %Y')
        reminder_dict = {'message': reminder_message, 'time': reminder_time}
        add_reminder(reminder_dict)
        return f"Reminder set for {reminder_time_str} with this message: {reminder_message}"
    else:
        return "Sorry, I couldn't understand the reminder message or time. Please specify it clearly."


def extract_reminder_message(user_input):
    #remove common reminder phrases like "remind me", "can you remind me", etc.
    reminder_keywords_pattern = r'\b(remind me|can you remind me|set a reminder|please remind me|reminder)\b'
    
    #remove the leading reminder phrase (e.g., "Can you remind me to")
    clean_input = re.sub(reminder_keywords_pattern, '', user_input, flags=re.IGNORECASE).strip()
    
    #time-related patterns
    relative_time_pattern = r'(in|after|next) (\d+|an|a) (minutes?|hours?|days?|weeks?)'
    specific_time_pattern = r'at (\d{1,2}(:\d{2})?\s*(AM|PM))'
    specific_date_time_pattern = r'on \w+ \d{1,2}(?:th|st|nd|rd)?, \d{4} at \d{1,2}(:\d{2})?\s*(AM|PM)'
    
    combined_pattern = rf'({relative_time_pattern}|{specific_time_pattern}|{specific_date_time_pattern})'
    
    clean_message = re.sub(combined_pattern, '', clean_input, flags=re.IGNORECASE).strip() #remove the time-related phrases
    
    if clean_message.lower().startswith('to '):
        clean_message = clean_message[3:].strip()
    
    clean_message = re.sub(r'[{}]'.format(re.escape(string.punctuation)), '', clean_message)

    return clean_message

def check_reminders():
    global reminders
    current_time = datetime.now()
    if len(reminders)>0:
        for reminder in reminders[:]:
            if reminder['time'] <= current_time:
                print(f"Reminder: {reminder['message']}")
                send_alert(message=f"Reminder: {reminder['message']}")
                reminders.remove(reminder)  #remove the reminder once it's triggered
                save_reminders_to_file()  # Update the file after removing
