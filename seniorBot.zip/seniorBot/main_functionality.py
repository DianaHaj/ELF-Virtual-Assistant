import os
import json
import openai
from openai import OpenAI
from datetime import datetime
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
from medical_rag_implementation import setup_rag_chain
from langchain.memory import  ConversationSummaryBufferMemory

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")
model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
personal_data_path = '/data/perfilEnglish.json'


def classify_question(question):
    prompt = f"""
    You are a classifier that distinguishes between types of questions. Your task is to classify each question into one of the following categories:

    1. **Medical**: Questions related to health, medical concerns, physical or mental well-being.
    2. **Personal**: Questions related to personal information, preferences, experiences, hobbies, and suggestions.
    3. **Reminder**: The query is related to setting a reminder. 
    4. **Weather**: Questions related to the weather forecast.

    Here are some examples:

    - "Do you have any health concerns you would like to share?" → Medical
    - "What book would you recommend me?", "What can I make today for lunch?  → Personal
    - "Can you remind me to take my medicine tomorrow at 10am" → Reminder 
    - "What will the weather be like for the rest of the day?" -> Weather 

    If it doesn't fall in any of those two categories and you see that it is a general question, classify it as unknown.
    If it is a reminder, return the word
    Now classify the following question:

    Question: "{question}"
    """
    message = {
        'role': 'user',
        'content': prompt}
    
    client = OpenAI(
    api_key=openai.api_key,)
    
    response = client.chat.completions.create(
        model='gpt-3.5-turbo',
        messages=[message])  
    chatbot_response = response.choices[0].message.content

    if "medical" in chatbot_response.lower():
        return "medical"
    elif "personal" in chatbot_response.lower():
        return "personal"
    elif "reminder" in chatbot_response.lower():
        return "reminder"
    elif "weather" in chatbot_response.lower():
        return "weather"
    else:
        return "unknown"


def ask_medical_question(question, summary_memory):
    response = setup_rag_chain(question, summary_memory)
    return response


def save_conversation(user_id, full_memory):
    file_path = f'/conversation_history/{user_id}_conversation.json'
    
    # Initialize data structure
    if os.path.exists(file_path):
        with open(file_path, 'r') as f:
            data = json.load(f)
    else:
        data = {}

    # Ensure there's an entry for the user
    if user_id not in data:
        data[user_id] = []

    # Prepare the conversation data
    memory_variables = full_memory.load_memory_variables({})
    chat_history_str = memory_variables['chat_history']
    messages = chat_history_str.strip().split('\n')

    conversation = []
    for message in messages:
        if message.startswith('Human:'):
            role = 'user'
            content = message[len('Human: '):].strip()
        elif message.startswith('AI:'):
            role = 'assistant'
            content = message[len('AI: '):].strip()
        else:
            continue  # Skip if the message format is unknown

        conversation.append({"role": role, "message": content})

    # Append the new conversation entry with a timestamp
    data[user_id].append({
        "timestamp": datetime.now().isoformat(),
        "conversation": conversation
    })

    # Save the updated data back to the file
    with open(file_path, 'w') as f:
        json.dump(data, f, indent=2)


def chat_with_openai(question: str, summary_memory: ConversationSummaryBufferMemory) -> str:
    prompt = f"""
    You are a personal assistant to elderly people. Try to assist the senior, be kind and show interest for their well-being and animic state. Here is the chat history:
    {summary_memory}
    Given the following question or interaction from the user, provide the most precise and reasonable answer:
    {question}
    """
    
    message = {
        'role': 'user',
        'content': prompt
    }
    
    client = OpenAI(api_key=openai.api_key)
    
    response = client.chat.completions.create(
        model='gpt-3.5-turbo',
        messages=[message]
    )  
    
    chatbot_response = response.choices[0].message.content
    return chatbot_response.strip()
