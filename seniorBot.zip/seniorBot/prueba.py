from dotenv import load_dotenv
import os, openai
from openai import OpenAI
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")


def classify_question(question):
    prompt = f"""
    You are a classifier that distinguishes between types of questions. Your task is to classify each question into one of the following categories:

    1. **Medical**: Questions related to health, medical concerns, physical or mental well-being.
    2. **Personal**: Questions related to personal information, preferences, experiences, hobbies, and suggestions.
    3. **Reminder**: The query is related to setting a reminder. 
    4. **Weather**: Questions related to the weather forecast.

    Here are some examples:

    - "Do you have any health concerns you would like to share?" → Medical
    - "What book would you recommend me?", "What can I make today for lunch?  → Personal
    - "Can you remind me to take my medicine tomorrow at 10am" → Reminder 
    - "What will the weather be like for the rest of the day?" -> Weather 

    If it doesn't fall in any of those two categories and you see that it is a general question, classify it as unknown.
    If it is a reminder, return the word
    Now classify the following question:

    Question: "{question}"
    """
    message = {
        'role': 'user',
        'content': prompt}
    
    client = OpenAI(
    api_key=openai.api_key,)
    
    response = client.chat.completions.create(
        model='gpt-3.5-turbo',
        messages=[message])  
    chatbot_response = response.choices[0].message.content

    if "medical" in chatbot_response.lower():
        return "medical"
    elif "personal" in chatbot_response.lower():
        return "personal"
    elif "reminder" in chatbot_response.lower():
        return "reminder"
    elif "weather" in chatbot_response.lower():
        return "weather"
    else:
        return "unknown"

import re , string

def extract_reminder_message(user_input):
    # Remove common reminder phrases like "remind me", "can you remind me", etc.
    reminder_keywords_pattern = r'\b(remind me|can you remind me|set a reminder|please remind me|reminder)\b'
    
    # Remove the leading reminder phrase (e.g., "Can you remind me to")
    clean_input = re.sub(reminder_keywords_pattern, '', user_input, flags=re.IGNORECASE).strip()
    
    # Time-related patterns (as already defined)
    relative_time_pattern = r'(in|after|next) (\d+|an|a) (minutes?|hours?|days?|weeks?)'
    specific_time_pattern = r'at (\d{1,2}(:\d{2})?\s*(AM|PM))'
    specific_date_time_pattern = r'on \w+ \d{1,2}(?:th|st|nd|rd)?, \d{4} at \d{1,2}(:\d{2})?\s*(AM|PM)'
    
    # Combine the patterns into one for simplification
    combined_pattern = rf'({relative_time_pattern}|{specific_time_pattern}|{specific_date_time_pattern})'
    
    # Remove the time-related phrases
    clean_message = re.sub(combined_pattern, '', clean_input, flags=re.IGNORECASE).strip()
    
    # Optional: Clean up leading "to" (e.g., "to call my mom" -> "call my mom")
    if clean_message.lower().startswith('to '):
        clean_message = clean_message[3:].strip()
    
    clean_message = re.sub(r'[{}]'.format(re.escape(string.punctuation)), '', clean_message)

    return clean_message

print(extract_reminder_message('Can you remind me to take the dog out in a minute?'))
    
#print(classify_question('ca.'))

