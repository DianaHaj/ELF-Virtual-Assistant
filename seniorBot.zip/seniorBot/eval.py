import json

# Load JSON data from a file
with open('/Users/dianahaj/Desktop/seniorBot/data/jsonformatter.txt') as json_file:
    data = json.load(json_file)

from collections import Counter
import pprint

# Pretty-print JSON data to understand its structure
#pprint.pprint(data)

# Count the number of conditions
num_conditions = len(data)
print(f"Number of medical conditions: {num_conditions}")

# Initialize a dictionary to hold lengths for each condition and category
content_lengths = {}

for condition, details in data.items():
    content_lengths[condition] = {}
    for category, content in details.items():
        # Calculate the length of the content string
        content_lengths[condition][category] = len(content)

import matplotlib.pyplot as plt

#category_sums = {category: sum(subcategories.values()) for category, subcategories in content_lengths.items()}

subcategory_counter = Counter()

for subcategories in content_lengths.values():
    subcategory_counter.update(subcategories)

# Convert to a sorted list of tuples
most_common_subcategories = subcategory_counter.most_common(10)

# Separate the subcategory names and their counts
subcategories, counts = zip(*most_common_subcategories)

# Plotting the results
plt.figure(figsize=(14, 11))
plt.bar(subcategories, counts, color='#58508d')
plt.xlabel('Subcategory')
plt.ylabel('Total Count')
plt.title('Most Common Subcategories')
plt.xticks(rotation=45, ha="right")
#plt.savefig('top_10_subcategories_nhs.png', bbox_inches='tight')  # You can specify the file path and format


def extract_text_from_json(data):
    if isinstance(data, dict):
        text = ''
        for key, value in data.items():
            text += ' ' + extract_text_from_json(value)
        return text
    elif isinstance(data, list):
        return ' '.join([extract_text_from_json(item) for item in data])
    else:
        return str(data)

# Extract all text from the JSON
all_text = extract_text_from_json(data)
from wordcloud import WordCloud
# Generate the word cloud
wordcloud = WordCloud(width=800, height=400, background_color='white').generate(all_text)

# Display the word cloud using matplotlib
plt.figure(figsize=(10, 5))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
#plt.show()

# Save the word cloud as an image file
#wordcloud.to_file('word_cloud.png')

with open('/Users/dianahaj/Desktop/seniorBot/data/intents.json') as json_file:
    intents = json.load(json_file)

count = 0
for i in intents['intents']:
    print(i['tag'])
    count += 1
print('count:', count)



'''

#pprint.pprint(content_lengths)
from wordcloud import WordCloud
import matplotlib.pyplot as plt

# Combine all text content
all_text = ' '.join(
    content for condition, details in data.items() for category, content in details.items()
)


# Generate word cloud
wordcloud = WordCloud(width=800, height=400, background_color='white').generate(all_text)

# Display word cloud
plt.figure(figsize=(12, 6))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
plt.title('Word Cloud of Keywords')
plt.show()




import pandas as pd
import statistics
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
from sentence_transformers import SentenceTransformer
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from rouge_score import rouge_scorer
from nltk.translate.meteor_score import meteor_score

# Load the medium-sized SentenceTransformer model
model_st = SentenceTransformer('all-MiniLM-L6-v2')

# Load the CSV file
file_path = '/Users/dianahaj/Desktop/seniorBot/Evaluation/responses.csv'  
data = pd.read_csv(file_path)

questions = []
for i in range(0, len(data.columns) - 1):
    column = data.iloc[:, i]  # Replace with the appropriate column index

    # Step 1: Extract the text (header) from the column name
    header_text = column.name

    # Split the header into the desired parts and remove any empty strings
    parts = [part.strip() for part in header_text.split("\n") if part.strip()]

    # Initialize variables
    question = None
    model_response = []
    expected_answer = []
    mode = None  # Used to track which part we are capturing

    # Step 2: Iterate over the parts to populate the question, model response, and expected answer
    for part in parts:
        if part.startswith("Question:"):
            question = part.replace("Question: ", "").strip()
        elif part.startswith("Model's Response:"):
            mode = "model_response"
            model_response.append(part.replace("Model's Response:", "").strip())
        elif part.startswith("Expected Ideal Answer:"):
            mode = "expected_answer"
            expected_answer.append(part.replace("Expected Ideal Answer:", "").strip())
        else:
            if mode == "model_response":
                model_response.append(part)
            elif mode == "expected_answer":
                expected_answer.append(part)

    # Step 3: Join the lists into strings
    model_response = " ".join(model_response).strip()
    expected_answer = " ".join(expected_answer).strip()

    # Step 4: Extract the evaluation numbers
    evaluation_numbers = column.tolist()  # Convert the column values to a list
    

    # Step 5: Create the dictionary
    question_dict = {
        "Question": question,
        "Model Response": model_response,
        "Expected Answer": expected_answer,
        "Evaluation Numbers": evaluation_numbers,
        "Mean" : statistics.mean(evaluation_numbers), 
        "Mode" : statistics.mode(evaluation_numbers)
    }

    # Print the result
    questions.append(question_dict)


# Define metric functions
def cosine_similarity_score(response, expected):
    vectorizer = TfidfVectorizer().fit_transform([response, expected])
    vectors = vectorizer.toarray()
    return cosine_similarity(vectors)[0, 1]

def sentence_bert_score(response, expected):
    embeddings = model_st.encode([response, expected])
    return cosine_similarity([embeddings[0]], [embeddings[1]])[0][0]

def bleu_score(response, expected):
    smoothie = SmoothingFunction().method1
    return sentence_bleu([expected.split()], response.split(), weights=(0.5, 0.5), smoothing_function=smoothie)


def rouge_score(response, expected):
    scorer = rouge_scorer.RougeScorer(['rouge1', 'rougeL'], use_stemmer=True)
    scores = scorer.score(expected, response)
    return scores['rouge1'].fmeasure


from sklearn.metrics.pairwise import cosine_similarity
from transformers import BertTokenizer, BertModel
import torch
from nltk.tokenize import word_tokenize
from nltk.translate.meteor_score import meteor_score

# Load the BERT model and tokenizer
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertModel.from_pretrained('bert-base-uncased')

# Function to compute token overlap
def token_overlap_score(response, expected):
    response_tokens = set(word_tokenize(response.lower()))
    expected_tokens = set(word_tokenize(expected.lower()))
    overlap = response_tokens.intersection(expected_tokens)
    return len(overlap) / len(expected_tokens)

# Function to compute BERT embedding similarity
def bert_embedding_similarity(response, expected):
    # Tokenize and encode the sentences
    response_inputs = tokenizer(response, return_tensors='pt', truncation=True, max_length=512)
    expected_inputs = tokenizer(expected, return_tensors='pt', truncation=True, max_length=512)
    
    # Get the embeddings
    with torch.no_grad():
        response_outputs = model(**response_inputs)
        expected_outputs = model(**expected_inputs)
    
    # Use the [CLS] token embeddings to represent the sentences
    response_embedding = response_outputs.last_hidden_state[:, 0, :].numpy()
    expected_embedding = expected_outputs.last_hidden_state[:, 0, :].numpy()
    
    # Compute cosine similarity
    similarity = cosine_similarity(response_embedding, expected_embedding)
    return similarity[0][0]

# Function to calculate METEOR score
def calculate_meteor_score(response, expected):
    response, expected = response.split(), expected.split()
    return nltk.translate.meteor_score.meteor_score([expected],response)


def calculate_metrics(entry):
    response = entry['Model Response']
    expected = entry['Expected Answer']
    

    metrics = {
        'Cosine Similarity': cosine_similarity_score(response, expected),
        'Sentence-BERT Similarity': sentence_bert_score(response, expected),
        'BLEU Score': bleu_score(response, expected),
        'ROUGE Score': rouge_score(response, expected),
        'METEOR Score': calculate_meteor_score(response, expected),
        'BERT Embedding Cosine Similarity': bert_embedding_similarity(response, expected),
        'Token Overlap': token_overlap_score(response, expected),
        'Human Mean Evaluation': entry['Mean']
    }
    
    return metrics

# Assume 'data' is your list of dictionaries
results = [calculate_metrics(entry) for entry in questions]

# Create a DataFrame
df_results = pd.DataFrame(results)

print(df_results)


####################### Rescale of metrics ###################

'''