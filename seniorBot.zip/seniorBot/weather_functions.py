from datetime import datetime
import requests

def get_user_location():
    #ipinfo.io to get location data
    response = requests.get('https://ipinfo.io')
    data = response.json()
    location = data['loc'].split(',')
    return {
        'city': data['city'],
        'region': data['region'],
        'country': data['country'],
        'latitude': location[0],
        'longitude': location[1]
    }

#Open-Meteo API call
def get_weather_data(latitude, longitude):
    url = f"https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}&current_weather=true&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m"
    response = requests.get(url)
    weather_data = response.json()
    return weather_data

#parsing of current weather data
def parse_current_weather_data(weather_data):
    current_weather = weather_data['current_weather']
    temperature = current_weather['temperature']
    wind_speed = current_weather['windspeed']
    
    weather = {
        'temperature': temperature,
        'wind_speed': wind_speed}
    return weather

#parsing hourly weather data
def parse_hourly_weather_data(weather_data):
    hourly_data = weather_data['hourly']
    times = hourly_data['time']
    temperatures = hourly_data['temperature_2m']
    wind_speeds = hourly_data['wind_speed_10m']

    today_date =  datetime.today().strftime('%Y-%m-%d')
    
    hourly_forecasts = []
    for time, temp, wind in zip(times, temperatures, wind_speeds):
        if time.startswith(today_date):
            forecast = {
                'time': time,
                'temperature': temp,
                'wind_speed': wind
            }
            hourly_forecasts.append(forecast)
        
    return hourly_forecasts


def summarize_weather_forecast(forecast_data, current_time):
    if not forecast_data:
        return "No forecast data available."

    # time to 12-hour format with AM/PM
    def format_time_12hr(time_str):
        hour, minute = map(int, time_str.split(':'))
        period = "am" if hour < 12 else "pm"
        hour = hour % 12 or 12
        return f"{hour}:{minute:02d} {period}"

    # forecast data closest to the current time
    closest_forecast = min(forecast_data, key=lambda x: abs(int(x['time'][-5:].replace(":", "")) - int(current_time.replace(":", ""))))
    current_temp = closest_forecast['temperature']
    start_time = format_time_12hr(closest_forecast['time'][-5:])

    min_temp = min(forecast_data, key=lambda x: x['temperature'])
    max_temp = max(forecast_data, key=lambda x: x['temperature'])
    min_temp_time = format_time_12hr(min_temp['time'][-5:])
    max_temp_time = format_time_12hr(max_temp['time'][-5:])

    max_wind = max(forecast_data, key=lambda x: x['wind_speed'])
    average_wind_speed = sum(item['wind_speed'] for item in forecast_data) / len(forecast_data)

    summary = []
    
    #current condition
    summary.append(f"The current temperature is {current_temp}°C at {start_time}.")

    #description of the temperature trend
    if max_temp['time'] < min_temp['time']:
        summary.append(f"Temperatures will rise, reaching a peak of {max_temp['temperature']}°C around {max_temp_time}, before cooling down to {min_temp['temperature']}°C by {min_temp_time}.")
    else:
        summary.append(f"The temperature will gradually rise to {max_temp['temperature']}°C by {max_temp_time}, then cool down to {min_temp['temperature']}°C by {min_temp_time}.")

    #mention wind speed only if it exceeds the average significantly
    if max_wind['wind_speed'] > average_wind_speed:
        summary.append(f"The strongest winds will reach {max_wind['wind_speed']} meters per second around {format_time_12hr(max_wind['time'][-5:])}.")

    #mentions any significant drops or rises
    if max_temp['temperature'] - min_temp['temperature'] > 5:
        summary.append(f"Expect a significant temperature change of over 5 degrees Celsius during the day.")
    elif max_temp['temperature'] - min_temp['temperature'] < 2:
        summary.append(f"Temperatures will remain fairly stable throughout the day.")

    return " ".join(summary)

def suggest_activity(temperature, wind_speed):
    if temperature > 20 and wind_speed < 15:
        return "It's a great time for a walk in the park!"
    elif temperature < 10:
        return "It's a bit chilly. How about some indoor activities like visiting a museum?"
    else:
        return "Enjoy a nice cup of coffee at a local café!"
    

user_location = get_user_location()
latitude, longitude = user_location['latitude'], user_location['longitude']
time_now = (datetime.now()).strftime('%H:%M')

weather_data = get_weather_data(latitude, longitude)
temperature, wind_speed = parse_current_weather_data(weather_data)

hourly_weather_data = (parse_hourly_weather_data(weather_data))

