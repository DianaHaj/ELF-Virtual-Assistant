import os
import torch
import pandas as pd
import json
import openai
from openai import OpenAI
from langchain_openai import ChatOpenAI
#from langchain.llms import OpenAI
#from langchain.llms import OpenAI as LangchainOpenAI
from langchain_community.llms import OpenAI as LangchainOpenAI
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer, util
from langchain.prompts import PromptTemplate
from langchain.chains.question_answering import load_qa_chain
from langchain.memory import ConversationSummaryBufferMemory

os.environ["TOKENIZERS_PARALLELISM"] = "false"
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

# Global variables to hold pre-loaded data and embeddings
questions = None
answers = None
question_embeddings = None

json_file_path = '/data/sampleProfile.json'


def load_json_data(file_path: str) -> pd.DataFrame:
    with open(file_path, 'r', encoding='utf-8') as file:
        data = json.load(file)
    
    df = pd.DataFrame(data)
    return df

def embed_questions(questions: list, device: str) -> torch.Tensor:
    question_embeddings = model.encode(questions, convert_to_tensor=True, device=device)
    return question_embeddings

def find_most_similar_question(query_question: str, question_embeddings: torch.Tensor, device: str) -> int:
    query_embedding = model.encode(query_question, convert_to_tensor=True, device=device)
    
    # Compute cosine similarity between query and all questions
    cosine_scores = util.pytorch_cos_sim(query_embedding, question_embeddings)[0]
    
    # Get the index of the most similar question
    most_similar_idx = torch.argmax(cosine_scores).item()
    
    return most_similar_idx

def chat_with_openai(prompt):
    message = {
        'role': 'user',
        'content': prompt}
    
    client = OpenAI(
    api_key=openai.api_key,)
    
    response = client.chat.completions.create(
        model='gpt-3.5-turbo',
        messages=[message])  
    chatbot_response = response.choices[0].message.content
    return chatbot_response.strip()

def ask_personal_question(question: str, memory: ConversationSummaryBufferMemory, weather_data=None, location=None) -> (str, ConversationSummaryBufferMemory):
    global questions, answers, question_embeddings
    device = "cuda" if torch.cuda.is_available() else "cpu"
    most_similar_idx = find_most_similar_question(question, question_embeddings, device)
    #most_similar_question = questions[most_similar_idx]
    answer = answers[most_similar_idx]

    context = memory.load_memory_variables({})

    prompt = f"""
    Here is a question: {question}
    Here is the context answer based on the information of the user: {answer}
    Here is the conversation context: {context}
    Please provide a refined response based on the preferences of the user.
    If the question is related to recommending an activity, have into account the weather and location of the user provided next. The current weather data is: {location},{weather_data}."""
    
    #memory.save_context({"input": question}, {"output": refined_answer})
    refined_answer = chat_with_openai(prompt)

    return refined_answer

def initialize_data(json_file_path: str):
    global questions, answers, question_embeddings
    
    # Load JSON data
    df = load_json_data(json_file_path)
    
    # Extract questions and answers from DataFrame
    questions = df['question'].tolist()
    answers = df['answer'].tolist()
    
    # Determine the device (CPU or GPU)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    
    # Embed questions
    question_embeddings = embed_questions(questions, device)
