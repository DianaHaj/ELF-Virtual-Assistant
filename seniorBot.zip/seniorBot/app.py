import streamlit as st
from streamlit_mic_recorder import speech_to_text
import time, os, openai
from datetime import datetime
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
from gtts import gTTS
import playsound
import base64


from personal_rag_implementation import ask_personal_question , initialize_data
#from imp_med2 import setup_rag_chain
from weather_functions import get_user_location, get_weather_data, parse_current_weather_data, parse_hourly_weather_data, summarize_weather_forecast
from reminders import load_reminders_from_file, check_reminders, handle_user_input #, add_reminder, parse_date_time, save_reminders_to_file
from main_functionality import classify_question, chat_with_openai, ask_medical_question, save_conversation
from langchain.memory import ConversationBufferMemory, ConversationSummaryBufferMemory
from langchain_openai import ChatOpenAI
from streamlit_notifications import send_alert 

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")
model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
personal_data_path = 'data/sampleProfile.json'
force_download=True


def initialize_memory():
    llm = ChatOpenAI(
        model="gpt-3.5-turbo",
        temperature=0,
        max_tokens=None,
        timeout=None,
        max_retries=2
    )
    summary_memory = ConversationSummaryBufferMemory(llm=llm)
    full_memory = ConversationBufferMemory(memory_key="chat_history", input_key="human_input", return_messages=False)
    return summary_memory, full_memory

def capture_speech():
    text = speech_to_text(
        language='en',
        start_prompt="Start recording",
        stop_prompt="Stop recording",
        just_once=False,
        use_container_width=False,
        callback=None,
        args=(),
        kwargs={},
        key="speech_to_text")
    return text

# Function to capture speech input
def capture_speech():    
    text = speech_to_text(
        language='en',
        start_prompt="Start recording",
        stop_prompt="Stop recording",
        just_once=False,
        use_container_width=False,
        callback=None,
        args=(),
        kwargs={},
        key=None)
    return text



def generate_unique_key(prefix=""):
    return f"{prefix}_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"

def display_interface(text):
    if text:
        st.write("Transcribed Text:")
        st.write(text)
        unique_button_key = generate_unique_key("answer_button")
        return st.button("Get Answer from LLM", key=unique_button_key)
    return False


def speak(text):
    tts = gTTS(text=text, lang='en')

    filename = "abc.mp3" 
    tts.save(filename)
    playsound.playsound(filename)
    os.remove(filename)

def display_answer(answer):
    st.write("Answer from LLM:")
    st.write(answer)

def generate_audio(text, filename):
    tts = gTTS(text=text, lang='en')
    tts.save(filename)

def autoplay_audio(file_path: str):
    with open(file_path, "rb") as f:
        data = f.read()
        b64 = base64.b64encode(data).decode()
        md = f"""
            <audio controls>
            <source src="data:audio/mp3;base64,{b64}" type="audio/mp3">
            </audio>
            """
        st.markdown(md, unsafe_allow_html=True)



def reminder_announcer():
    while True:
        if 'reminders' in st.session_state:
            for reminder in st.session_state['reminders']:
                st.write(f"Reminder: {reminder['message']}")
                # Send a notification alert
                send_alert(message=f"Reminder: {reminder['message']}")
            time.sleep(60)  # Check every minute

            
st.markdown("""
    <style>
    .stButton button {
        padding: 18px px;
        font-size: 26px;
    }
    </style>
    """, unsafe_allow_html=True)

        
def main():
    st.title(":green[_ELF_] :elf: Virtual Assistant ")

    st.markdown("""
    #### Welcome! I am the Elderly Life Friend. Here’s how I can help you:<br>

    <ul style='list-style-type: none; padding-left: 0;'>
        <li><strong>Medical Help:</strong> Ask about illnesses or treatments.</li>
        <li><strong>Personal Questions:</strong> Get personalized recommendations.</li>
        <li><strong>Set Reminders:</strong> Easily set reminders for tasks or events.</li>
        <li><strong>Weather Updates:</strong> Check the weather anytime.</li>
        <li><strong>General Questions:</strong> Ask anything else, and get helpful answers.</li>
    </ul>
                
   <strong>Sample Questions:</strong> <br>
    <ul style='list-style-type: none; padding-left: 0;'>
        <li><strong>Medical Help:</strong> "What are the symptoms of coronary heart disease? / What to do if I have a cut?"</li>
        <li><strong>Personal Questions:</strong> "Recommend a good book for me / a cool place to visit in my city."</li>
        <li><strong>Set Reminders:</strong> "Remind me to take my medication at 5 PM."</li>
        <li><strong>Weather Updates:</strong> "What's the weather like today?"</li>
        <li><strong>General Questions:</strong> "Tell me names of famous painters."</li>
    </ul>
                
    #### Just type or speak your question, and we’ll take care of the rest!
    """, unsafe_allow_html=True)

    # Initialize session state for interactions and reminders
    if 'interactions' not in st.session_state:
        st.session_state['interactions'] = []

    load_reminders_from_file()
    check_reminders()
    
    if 'current_response' not in st.session_state:
        st.session_state['current_response'] = None

    # Initialize memory buffers
    if 'summary_memory' not in st.session_state:
        summary_memory, full_memory = initialize_memory()
        st.session_state['summary_memory'] = summary_memory
        st.session_state['full_memory'] = full_memory
    else:
        summary_memory = st.session_state['summary_memory']
        full_memory = st.session_state['full_memory']
    
    # Initialize personal data and weather
    personal_data_path = 'data/sampleProfile.json'
    initialize_data(personal_data_path)
    
    user_location = get_user_location()
    latitude, longitude = user_location['latitude'], user_location['longitude']
    time_now = datetime.now().strftime('%H:%M')
    current_datetime = (datetime.now()).strftime('%Y-%m-%d %H:%M')

    weather_data = get_weather_data(latitude, longitude)
    current_weather = parse_current_weather_data(weather_data)
    hourly_weather_data = parse_hourly_weather_data(weather_data)

    st.write("")
    st.write("You can either **speak** or **type** your question below:")

    text = capture_speech() #text input from the user

    with st.form('user_input_form'):
        text_input = st.text_input("Or type your question here:")
        submit_button = st.form_submit_button(label='Submit')

        
        if submit_button and text_input: #if the user submits text via typing
            text = text_input
            

    if text:
        st.write(f'This is the question I captured: *{text}*. I am generating the answer now, give me a moment please!')
        question_type = classify_question(text) #determine the question type
        print(question_type, 'the questionnnn')
        try:
            if question_type == 'reminder': 
                response = handle_user_input(text)
                st.write(response)
            elif question_type == 'medical':
                response = ask_medical_question(text, summary_memory)
            elif question_type == 'personal':
                response = ask_personal_question(text, summary_memory, current_weather, user_location)#response = chat_with_openai(text, summary_memory
            elif question_type == 'weather':
                response = summarize_weather_forecast(hourly_weather_data, time_now)
            else:
                response = chat_with_openai(text, summary_memory)
        except Exception as e: 
            response = "Sorry, I didn't get that. An error occurred! Please try asking or telling me again." 
            st.write(response)
            print(e)

        st.session_state['current_response'] = response
        st.session_state['interactions'].append({'user_query': text, 'model_response': response})
       
        try: 
            filename = "response_audio.mp3"
            generate_audio(response, filename)
            st.write("Audio generated. Click the button below to play it.")
        except: 
            st.write("An error ocurred and the audio file wasn't generated")

        # Save conversation history using memory buffers
        summary_memory.save_context({"human_input": text}, {"output": response})
        summary_memory.load_memory_variables({})
        
        full_memory.save_context({"human_input": text}, {"output": response})
        full_memory.load_memory_variables({})

        print(full_memory)


    if st.session_state['current_response']:
        st.write("Answer from LLM:")
        st.write(st.session_state['current_response'])
        
        autoplay_audio("response_audio.mp3")


    st.write("Thank you for using ELF Virtual Assistant! If you don’t need any more help, please click the button below to save your conversation. Have a wonderful day!")
    if st.checkbox("End Session"):
        user_id = '12345'
        try:
            save_conversation(user_id, full_memory)
            st.write("Conversation and reminders saved successfully!")
            st.stop()  # End the session after saving
            #clean session not to repeat chat history saved
        except Exception as e:
            st.error(f"Failed to save conversation: {str(e)}")


if __name__ == "__main__":
    main()
    while True:
        check_reminders()
        time.sleep(60) 
