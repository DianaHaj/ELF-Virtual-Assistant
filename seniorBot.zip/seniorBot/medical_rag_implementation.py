import os
import json
import openai
from openai import OpenAI
from langchain_community.vectorstores import Chroma
from langchain_openai import ChatOpenAI
from langchain_core.runnables import RunnablePassthrough
from dotenv import load_dotenv
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import RecursiveJsonSplitter

_vectorstore = None
_rag_chain = None

def setup_vectorstore():
    global _vectorstore
    if _vectorstore is None:
        print('initializing vectorstore')
        with open('data/nhs.txt', encoding = 'utf8') as json_file:
            data = json.load(json_file)
        
        with open('data/medical_kaggle.json', encoding = 'utf8') as json_file2:
            data2 = json.load(json_file2)

        embedding_function = OpenAIEmbeddings(openai_api_key=openai.api_key)
        splitter = RecursiveJsonSplitter()
        splitter2 = RecursiveJsonSplitter(max_chunk_size=300)

        docs = splitter.create_documents(texts=[data])
        _vectorstore = Chroma.from_documents(documents=docs, embedding=embedding_function)

        # Add additional JSON documents
        additional_docs = splitter2.create_documents(texts=[data2])
        _vectorstore.add_documents(additional_docs)
    
    return _vectorstore


def chat_with_openai(prompt):
    message = {
        'role': 'user',
        'content': prompt}
    
    client = OpenAI(
    api_key=openai.api_key,)
    
    response = client.chat.completions.create(
        model='gpt-3.5-turbo',
        messages=[message])  
    chatbot_response = response.choices[0].message.content
    return chatbot_response.strip()


def setup_rag_chain(question, summary_memory):
    global _rag_chain
    if _rag_chain is None:
        vectorstore = setup_vectorstore()
        retriever = vectorstore.as_retriever()
        
        # Extract chat history as a string
        chat_history = summary_memory.load_memory_variables({})
        print('done chathist')
        def format_docs(docs):
            return "\n\n".join(doc.page_content for doc in docs)
        print('done docs')
        llm = ChatOpenAI(model="gpt-3.5-turbo")

        refined_answer = chat_with_openai(f"""
        You are a medical chatbot for elderly people having a conversation with a human.Try to assist the senior, be kind and show interest for their well-being and animic state.
        Here is a question: {question}\nHere is the context information or documents: {retriever}, {format_docs}\n
        Here is the conversation context: {chat_history}\n
        Please provide a refined response based on the information provided. Tailor the answer knowing it will be read by a senior.""")
    
        return refined_answer
